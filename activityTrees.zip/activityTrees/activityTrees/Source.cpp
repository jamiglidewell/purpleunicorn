# include <iostream>
# include <time.h>

# include "CSVparser.hpp"

using namespace std;

//forward declarations 
doublee strToDouble(string str, char ch);

//define structure to hold bid
struct Bid {
	string bidID; //identifier
	string title; 
	string fund;
	double amount;
	Bid() {
		amount = 0.0;
	}
};

// FIXME (1): Internal sructure for tree node
struct Node {
	Bid bid;
	Node* left;
	Node* right;

//default constructor
Node() {
	left = nullptr;
	right = nullptr;
}

//initialize with bid
Node(Bid aBid) : Node() {
	this->bid = aBid;
}
};

//Binary Search Tree Class Definition

//Define a class containing data members and methods to implement search tree

class BinarySearchTree {
private:
	Node* root;
	void addNode(Node* node, Bid bid);
	void inOrder(Node* node);
	Node* removeNode(Node* node, string bidID);

public:
	BinarySearchTree();
	virtual ~BinarySearchTree();
	void InOrder();
	void Insert(Bid bid);
	void Remove(string bidId);
	Bid Search(string bidId);
};

//Default constructor

BinarySearchTree::BinarySearchTree() {
	root = nullptr;
}

//Destructor

BinarySearchTree::~BinarySearchTree() {

}

//Traverse tree in order

void BinarySearchTree::InOrder() {
	this->inOrder(root);
}

//Insert a bid

void BinarySearchTree::Insert(Bid bid) {
	//FIXME (2a) Implement inserting a bid into the tree
	if (root == nullptr) {
		root = new Node(bid);
	}
	else {
		this->addNode(root, bid);
	}
}

//Remove a bid

void BinarySearchTree::Remove(string bidId) {
	//FIXME (4a) Implement removing a bid from the tree
	this->removeNode(root, bidId);
}

//Search for a bid

Bid BinarySearchTree::Search(string bidId) {
	//FIXME (3) Implement searching the tree for a bid
	Node* current = root;

	//loop until he bid is found
	while (current != nullptr) {
		//return match if found
		if (current->bid.bidID.compare(bidId) == 0) {
			return current->bid;
		}
		//if bid is less add to left of subtree
		if (bidId.compare(current->bid.bidID) < 0) {
			current = current->left;
		}
		else {
			current = current->right;
		}
	}

	Bid bid;
	return bid;
}

//Add bid to some node

void BinarySearchTree::addNode(Node* node, Bid bid) {
	//FIXME (2b) Implement inserting bid into the tree

	//if node is greater than bid, add to left
	if (node->bid.bidID.compare(bid.bidID)) > 0) {
	if (node->left == nullptr) {
		node->left = new Node(bid);
	}
	else {
		this->addNode(node->left, bid);
	}
}
//add to the right subtree
	else {
		if (node->right == nullptr) {
			node->right = new Node(bid);
		}
		else {
			this->addNode(node->right, bid);
		}
	}
}
void BinarySearchTree::inOrder(Node* node) {
	if (node != nullptr) {
		inOrder(node->left);
		
		cout << node->bid.bidID << ": " << node->bid.title << " | " << node->bid.amount << " | "
			<< node->bid.fund << endl;

		InOrder(node->right);
	}
}

Node* BinarySearchTree::removeNode(Node* node, string bidId) {

	//recurse down left subtree
	if (bidId.compare(node->bid.bidID) < 0) {
		node->left = removeNode(node->left, bidId);
	}
	else if (bidId.compare(node->bid.bidId) > 0) {
		node->right = removeNode(node->right, bidId);
	}
	else {
		//no childre so this is a leaf node
		if (node->left == nullptr && node->right == nullptr) {
			delete node;
			node = nullptr;
		}
		//one child to the left
		else if (node->left != nullptr && node->left == nullptr) {
			Node* temp = node;
			nod = node->left;
			delete temp;
		}
		//one child to the right
		else if (node->right != nullptr && node->left == nullptr) {
			Node* temp = node;
			node = node->right;
			delete temp;
		}
		//two children
		else {
			Node* temp = node->right;
			while (temp->left != nullptr) {
				temp = temp->left;
			}
			node->bid = temp->bid;
			node->right = removeNode(node->right, temp->bid.bidId);
		}
	}
	return node;
}

